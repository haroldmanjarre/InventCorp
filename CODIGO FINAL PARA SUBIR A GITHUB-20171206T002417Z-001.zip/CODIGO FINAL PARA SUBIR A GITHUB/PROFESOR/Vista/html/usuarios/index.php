<?php
echo "Elemento Borrado";
?>