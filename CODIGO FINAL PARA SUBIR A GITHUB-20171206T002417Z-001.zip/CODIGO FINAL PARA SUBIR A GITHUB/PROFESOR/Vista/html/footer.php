<!DOCTYPE html>
<html lang="en">
<head>
  <title>Mi Proyecto</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
  <script src="../bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid">
<div class="row">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#" style="font-size:12px">SENA @ Todos los Derechos Reservados</a>
    </div>
    
    <ul class="nav navbar-nav navbar-right">
      <li class="pull-right"><a href="#"></span> ADSI</a></li>
    </ul>
  </div>
</nav>
</div>
</div>
</body>
</html>
