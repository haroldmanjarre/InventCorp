<?php
session_start();
if (!empty($_SESSION["session"]))
{
  header("Location:../../index.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

  <title>Mi Proyecto</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
  <script src="../bootstrap/js/bootstrap.min.js"></script>

 
</head>
<body>

<div class="container">
<header>
<?php include_once 'header.php'; ?>
</header>

  <div class="container">
   <div class="row">
        
   <?php //include_once 'menulateral.php'; ?>
				
  <div class="col-sm-12 col-md-12">
   <div class="panel panel-default">
   <!-- contenedor del titulo-->
   <div class="panel-heading">
    <h3 class="panel-title">EJERCICIOS DE PRACTICA PHP</h3>
   </div>
    <!-- contenedor de descripcion ejercicios-->
   <div class="panel-body">
   <p style="color:#DCA430">Formulario de registro de usuarios. </p>
    <!-- contenedor menu de ejercicios-->
  			  
			   <!-- Contenedor ejercicio-->
             
			   <div class="row">
			   <div class="col-sm-12 col-md-12">
               
			   <form name="areat" action="../../controlador/controler1.php" method="post">
			   <table class="" style="" align="center" width="400">
			
			   <tr><td align="center" style="font-family:Tahoma, Geneva, sans-serif">Usuario / Email</td><td>
  <input class="form-control input-sm" type="email" name="usu" class="form-control" placeholder="Correo electrónico" required>
</td></tr>
<tr><td style="padding:2px"></td></tr>
			   <tr><td align="center" style="font-family:Tahoma, Geneva, sans-serif">Nombre</td><td>
  <input class="form-control input-sm" type="text" name="nom" class="form-control" placeholder="Nombre" required>
</td></tr>
<tr><td style="padding:2px"></td></tr>
<tr><td align="center" style="font-family:Tahoma, Geneva, sans-serif">Apellido</td><td>
  <input class="form-control input-sm" type="text" name="ape" class="form-control" placeholder="Apellido" required>
</td></tr>
<tr><td style="padding:2px"></td></tr>
			   <tr><td align="center" style="font-family:Tahoma, Geneva, sans-serif">Contraseña</td><td>
  <input class="form-control input-sm" type="password" name="pass" class="form-control" placeholder="Contraseña" required>
</td></tr>
<tr><td style="padding:4px"></td></tr>
<tr><td colspan="2"><hr></td></tr>
<tr><td align="center" colspan="2"><input type="submit" name="registrar" style="width:400px" value="REGISTRAR"></td></tr>
<tr><td style="padding:4px"></td></tr>
<tr><?PHP if(isset($_REQUEST['dato'])){ echo "<td colspan='2' align='center'><div class='alert alert-success'>"."REGISTRO CORRECTO"."</div>";} if(isset($_REQUEST['dato1'])){ echo "<td colspan='2' align='center'><div class='alert alert-warning'>"."USUARIO YA SE ENCUENTRA EN EL SISTEMA"."</div>"; }?></td></tr>
			  
			   </table>
			   </form>
			   </div>
			  
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
 
</body>
</html>
