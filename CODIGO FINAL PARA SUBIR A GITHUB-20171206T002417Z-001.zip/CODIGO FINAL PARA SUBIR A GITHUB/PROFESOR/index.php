<!DOCTYPE html>
<html lang="en">
<head>
  <title>INVENTCORP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="vista/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
  <script src="vista/bootstrap/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
<header>
<?php include_once 'vista/html/header.php'; ?>
</header>


<?php include_once 'vista/html/slideshow.php'; ?><br>


<div class="container">
      <div class="row">
       <div class="col-md-2 column margintop20"> 
<ul class="nav nav-pills nav-stacked"> 
      <li class="active"><a href="index.php"><span class="glyphicon glyphicon-list"></span> Inicio</a></li>
      <li><a href="vista/html/usuarios/crudusuarios.php">Bd Usuarios<span class="glyphicon glyphicon-user pull-right"></span> </a></li>
      <li><a href="#">Bd Proveedores<span class="glyphicon glyphicon-globe pull-right"></span> </a></li>
      <li><a href="#">Bd Productos<span class="glyphicon glyphicon-shopping-cart pull-right"></span> </a></li>
      <li><a href="#">Bd Mantenimiento<span class="glyphicon glyphicon-list-alt pull-right"></span> </a></li>
      <li><a href="#">Bd Material<span class="glyphicon glyphicon-chevron-right pull-right"></span> </a></li>
      </ul>

		  </div>		
        <div class="col-sm-10 col-md-10">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title">Bienvenido a InventCorp</h3>
            </div>
            <div class="panel-body">
              <p>Páginas de inventarios, con programacion orientada a objetos, esta página fue hecha en lenguaje de programación PHP, HTML, CSS, SQL lo invitamos a explorar la pagina!</p><br>
              <div class="alert alert-success">
			   <div class="row">
			   	<div class="col-md-3" align="center"> <span><img src="Vista/imagenes/css.png" width="100" width="100"></span></div>
			    <div class="col-md-3" align="center"> <span><img src="Vista/imagenes/sql.png" width="100" width="100"></span></div>
			    <div class="col-md-3" align="center"> <span><img src="Vista/imagenes/html.png" width="130" width="130"></span></div>
				<div class="col-md-3" align="center"> <span><img src="Vista/imagenes/php.png" width="110" width="110"></span></div>
			</div>
			  
            </div>
          </div>
        </div>
      </div>
    </div>
         
      
</div>

</body>
</html>

